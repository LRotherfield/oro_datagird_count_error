-- MySQL dump 10.13  Distrib 5.6.16, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: bap_standard
-- ------------------------------------------------------
-- Server version	5.6.16-1~exp1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `df_item`
--

DROP TABLE IF EXISTS `df_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_item`
--

LOCK TABLES `df_item` WRITE;
/*!40000 ALTER TABLE `df_item` DISABLE KEYS */;
INSERT INTO `df_item` VALUES (1),(2),(3),(4);
/*!40000 ALTER TABLE `df_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_translation`
--

DROP TABLE IF EXISTS `df_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `active_version_id` int(11) DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_7BDD4D886A1E45F3` (`active_version_id`),
  KEY `IDX_7BDD4D88126F525E` (`item_id`),
  CONSTRAINT `FK_7BDD4D886A1E45F3` FOREIGN KEY (`active_version_id`) REFERENCES `df_version` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_7BDD4D88126F525E` FOREIGN KEY (`item_id`) REFERENCES `df_item` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_translation`
--

LOCK TABLES `df_translation` WRITE;
/*!40000 ALTER TABLE `df_translation` DISABLE KEYS */;
INSERT INTO `df_translation` VALUES (1,1,1,'en'),(2,1,2,'de'),(3,2,3,'en'),(4,2,4,'fr'),(5,2,5,'de'),(6,3,6,'en'),(7,3,7,'fr'),(8,4,8,'en'),(9,4,9,'es'),(10,4,10,'de'),(11,3,11,'es');
/*!40000 ALTER TABLE `df_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_version`
--

DROP TABLE IF EXISTS `df_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translation_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BA89D9859CAA2B25` (`translation_id`),
  CONSTRAINT `FK_BA89D9859CAA2B25` FOREIGN KEY (`translation_id`) REFERENCES `df_translation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_version`
--

LOCK TABLES `df_version` WRITE;
/*!40000 ALTER TABLE `df_version` DISABLE KEYS */;
INSERT INTO `df_version` VALUES (1,1,'Test [1] en'),(2,2,'Test [2] de'),(3,3,'Test [3] en'),(4,4,'Test [4] fr'),(5,5,'Test [5] de'),(6,6,'Test [6] en'),(7,7,'Test [7] fr'),(8,8,'Test [8] en'),(9,9,'Test [9] es'),(10,10,'Test [10] de'),(11,11,'Test [11] es');
/*!40000 ALTER TABLE `df_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-24 15:46:47
